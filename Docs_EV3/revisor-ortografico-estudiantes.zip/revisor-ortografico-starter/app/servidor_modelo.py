"""
Servidor del MODELO con el contrato de Amazon SageMaker (el mismo contenedor sirve local y en AWS).

SageMaker exige dos rutas en el puerto 8080:
  GET  /ping         -> 200 si el modelo esta cargado (health check)
  POST /invocations  -> recibe la imagen y devuelve el JSON con el resultado

Acepta la imagen como bytes (Content-Type image/png o image/jpeg) o como JSON {"imagen_base64": "..."}.
SageMaker deja el modelo descomprimido en /opt/ml/model (variable MODEL_DIR).
"""
from __future__ import annotations

import base64
import binascii
import io
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from PIL import Image, UnidentifiedImageError

from app.modelo import RevisorOrtografico

logging.basicConfig(level="INFO", format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("modelo")

@asynccontextmanager
async def _vida(_):
    revisor()  # carga el modelo al arrancar, antes de recibir trafico
    yield


app = FastAPI(title="Modelo revisor ortografico", docs_url=None, redoc_url=None, lifespan=_vida)
_revisor: RevisorOrtografico | None = None


def revisor() -> RevisorOrtografico:
    global _revisor
    if _revisor is None:
        _revisor = RevisorOrtografico.cargar()
        log.info("Modelo %s cargado", _revisor.meta.get("version"))
    return _revisor


@app.get("/ping")
def ping():
    try:
        revisor()
        return JSONResponse({"estado": "ok"})
    except Exception as e:  # noqa: BLE001
        return JSONResponse({"estado": "error", "detalle": str(e)}, status_code=503)


@app.post("/invocations")
async def invocar(request: Request):
    cuerpo = await request.body()
    tipo = request.headers.get("content-type", "").split(";")[0].strip().lower()
    try:
        if tipo == "application/json":
            import json
            cuerpo = base64.b64decode(json.loads(cuerpo)["imagen_base64"], validate=True)
        elif tipo not in ("image/png", "image/jpeg", "application/x-image", "application/octet-stream"):
            return JSONResponse({"error": f"Content-Type no soportado: {tipo}"}, status_code=415)
        imagen = Image.open(io.BytesIO(cuerpo))
        imagen.load()
    except (KeyError, ValueError, binascii.Error, UnidentifiedImageError, OSError):
        return JSONResponse({"error": "No se pudo leer la imagen (PNG o JPEG valida)."}, status_code=400)
    return JSONResponse(revisor().revisar(imagen))
