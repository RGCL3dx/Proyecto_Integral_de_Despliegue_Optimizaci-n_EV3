import csv
import sys
from pathlib import Path

import pytest

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))


@pytest.fixture(scope="session")
def etiquetas():
    with open(RAIZ / "datos" / "etiquetas.csv", newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


@pytest.fixture(scope="session")
def img_limpia(etiquetas):
    f = next(e for e in etiquetas if e["particion"] == "test" and e["tiene_faltas"] == "0" and e["dificultad"] == "facil")
    return RAIZ / "datos" / "imagenes" / f["archivo"]


@pytest.fixture(scope="session")
def img_con_falta(etiquetas):
    f = next(e for e in etiquetas if e["particion"] == "test" and e["tiene_faltas"] == "1" and e["dificultad"] == "facil")
    return RAIZ / "datos" / "imagenes" / f["archivo"], f
