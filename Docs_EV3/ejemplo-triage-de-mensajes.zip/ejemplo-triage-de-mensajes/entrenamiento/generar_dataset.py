"""Genera mensajes de clientes de una tienda en linea (inventados) y los etiqueta ALTA o NORMAL.
  python entrenamiento/generar_dataset.py --salida datos --cantidad 600 --semilla 3
Para que no sea trivial: hay mensajes ALTA sin palabras obvias y mensajes NORMAL que mencionan problemas sin urgencia."""
import argparse
import csv
import random
from pathlib import Path

ALTA = [
    "{u} mi pedido {n} llego roto y necesito un reembolso hoy",
    "me cobraron dos veces la compra {n}, {u}",
    "{u} no puedo pagar, la pagina se cae al confirmar el pedido {n}",
    "quiero reclamar: el producto del pedido {n} no funciona y nadie me responde",
    "{u} hackearon mi cuenta, hay compras que yo no hice",
    "llevo dos semanas esperando el pedido {n} y nadie contesta, voy a denunciar",
    "el cargo de mi tarjeta aparece duplicado y necesito que lo resuelvan {u}",
    "me llego un producto equivocado, es para un regalo de manana, {u}",
    "no me deja ingresar a mi cuenta y tengo un pedido pendiente {n}, {u}",
    "el repartidor dejo el pedido {n} en la direccion equivocada y ya no esta",
]
NORMAL = [
    "hola, quisiera saber el horario de atencion de la tienda",
    "gracias por el pedido {n}, llego perfecto",
    "me gustaria cotizar una compra por mayor de {n} unidades",
    "como puedo cambiar la direccion de despacho para futuras compras",
    "tienen disponible el modelo azul en talla {n}",
    "quiero actualizar mi correo electronico en la cuenta",
    "cual es el plazo normal de entrega a regiones",
    "buen dia, me pueden enviar la boleta del pedido {n} cuando puedan",
    "queria preguntar si el producto viene con garantia",
    "el pedido {n} aun no llega pero estoy dentro del plazo, solo consultaba",
    "la pagina cambio de color, me gusta mas el nuevo diseno",
]
URGENTE = ["urgente", "es urgente", "por favor ayuda", "necesito respuesta inmediata", "esto es grave", "ya", "por favor rapido"]
CIERRES = ["", "", " gracias", " saludos", " quedo atento", " muchas gracias"]


def mensaje(rng, etiqueta):
    plantilla = rng.choice(ALTA if etiqueta == "ALTA" else NORMAL)
    texto = plantilla.format(n=rng.randint(1000, 9999), u=rng.choice(URGENTE) if rng.random() < 0.5 else "")
    texto = " ".join(texto.replace(" ,", ",").split()).strip(" ,")
    if etiqueta == "NORMAL" and rng.random() < 0.15:
        texto += " " + rng.choice(["no es urgente", "sin apuro", "cuando puedan"])
    return texto + rng.choice(CIERRES)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--salida", default="datos")
    ap.add_argument("--cantidad", type=int, default=600)
    ap.add_argument("--semilla", type=int, default=3)
    a = ap.parse_args()
    rng = random.Random(a.semilla)
    Path(a.salida).mkdir(parents=True, exist_ok=True)
    filas = []
    for i in range(a.cantidad):
        et = "ALTA" if rng.random() < 0.4 else "NORMAL"
        filas.append({"id": i, "particion": "train" if i % 5 < 3 else "test", "texto": mensaje(rng, et), "prioridad": et})
    with open(Path(a.salida) / "mensajes.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(filas[0]))
        w.writeheader()
        w.writerows(filas)
    print(f"{len(filas)} mensajes en {a.salida}/mensajes.csv")


if __name__ == "__main__":
    main()
