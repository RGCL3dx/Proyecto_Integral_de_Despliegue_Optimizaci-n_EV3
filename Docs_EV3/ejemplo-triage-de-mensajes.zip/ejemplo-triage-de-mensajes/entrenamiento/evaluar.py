"""Mide el modelo con la particion test.   python entrenamiento/evaluar.py"""
import json
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))
from app.modelo import Triage  # noqa: E402
from entrenamiento.entrenar import leer  # noqa: E402


def prf(tp, fp, fn):
    p = tp / (tp + fp) if tp + fp else 0.0
    r = tp / (tp + fn) if tp + fn else 0.0
    return round(p, 3), round(r, 3), round(2 * p * r / (p + r), 3) if p + r else 0.0


if __name__ == "__main__":
    m, filas = Triage.cargar(), leer("test")
    tp = fp = fn = tn = manual = 0
    for texto, real in filas:
        d = m.predecir(texto)["decision"]
        if d == "REVISION_MANUAL":
            manual += 1
            continue
        pred_alta, real_alta = d == "ESCALAR", real == "ALTA"
        tp, fp, fn, tn = tp + (pred_alta and real_alta), fp + (pred_alta and not real_alta), fn + (not pred_alta and real_alta), tn + (not pred_alta and not real_alta)
    n = tp + fp + fn + tn
    p, r, f1 = prf(tp, fp, fn)
    res = {"mensajes_test": len(filas), "enviados_a_revision_manual": manual, "accuracy": round((tp + tn) / n, 3),
           "precision": p, "recall": r, "f1": f1, "matriz": {"TP": tp, "FP": fp, "FN": fn, "TN": tn}}
    # prueba "fuera de plantilla": 14 mensajes escritos a mano, distintos a los del entrenamiento
    import csv
    man = list(csv.DictReader(open(RAIZ / "datos" / "mensajes_manuales.csv", encoding="utf-8")))
    ok = nman = 0
    errores = []
    for f in man:
        d = m.predecir(f["texto"])
        pred = {"ESCALAR": "ALTA", "RESPONDER_NORMAL": "NORMAL"}.get(d["decision"], "INCIERTA")
        ok += pred == f["prioridad"]
        nman += d["decision"] == "REVISION_MANUAL"
        if pred != f["prioridad"]:
            errores.append({"texto": f["texto"], "real": f["prioridad"], "decision": d["decision"], "p_alta": d["probabilidad_alta"]})
    res["fuera_de_plantilla"] = {"mensajes": len(man), "aciertos": ok, "a_revision_manual": nman, "errores": errores}
    print(json.dumps(res, indent=2, ensure_ascii=False))
    (RAIZ / "resultados").mkdir(exist_ok=True)
    (RAIZ / "resultados" / "evaluacion.json").write_text(json.dumps(res, indent=2), encoding="utf-8")
