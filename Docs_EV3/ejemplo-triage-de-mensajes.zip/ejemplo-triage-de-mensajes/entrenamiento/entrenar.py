"""Entrena el modelo con la particion train y lo guarda en modelo/modelo.joblib.   python entrenamiento/entrenar.py"""
import csv
import json
import sys
from pathlib import Path

import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))


def leer(particion):
    with open(RAIZ / "datos" / "mensajes.csv", newline="", encoding="utf-8") as f:
        return [(r["texto"], r["prioridad"]) for r in csv.DictReader(f) if r["particion"] == particion]


if __name__ == "__main__":
    X, y = zip(*leer("train"))
    vec = TfidfVectorizer(ngram_range=(1, 2), min_df=2, strip_accents="unicode", lowercase=True)  # hiperparametros
    clf = LogisticRegression(C=3.0, max_iter=1000)
    clf.fit(vec.fit_transform(X), y)
    (RAIZ / "modelo").mkdir(exist_ok=True)
    joblib.dump({"vectorizador": vec, "clasificador": clf}, RAIZ / "modelo" / "modelo.joblib")
    (RAIZ / "modelo" / "modelo.json").write_text(json.dumps(
        {"tipo": "TF-IDF (1-2 gramas) + regresion logistica", "librerias": "scikit-learn", "C": 3.0,
         "mensajes_entrenamiento": len(X)}, indent=2), encoding="utf-8")
    print(f"Modelo guardado ({len(X)} mensajes de entrenamiento).")
