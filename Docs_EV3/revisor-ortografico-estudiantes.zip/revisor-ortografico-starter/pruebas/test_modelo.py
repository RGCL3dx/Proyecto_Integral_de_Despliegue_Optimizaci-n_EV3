"""Pruebas del modelo (sin red, sin AWS). Cubren casos con faltas, sin faltas, tildes y reglas de decision."""
from app.modelo import Palabra, RevisorOrtografico
import pytest

VOCAB = {"estudiantes": 100000, "inscripcion": 5000, "inscripción": 50000, "matricula": 2000, "matrícula": 40000,
         "proyectos": 80000, "para": 900000, "los": 900000}


@pytest.fixture(scope="module")
def rev():
    return RevisorOrtografico(VOCAB, {"umbral_zipf": 1.5, "razon_tilde": 2, "conf_ocr_min": 60, "largo_minimo": 3,
                                      "distancia_max": 1})


def p(t, conf=95):
    return Palabra(t, conf, 0, 0, 10, 10, 1)


def test_palabra_correcta_no_se_marca(rev):
    assert rev.revisar_palabras([p("estudiantes")])["decision"] == "APROBAR"


def test_no_palabra_se_marca_con_sugerencia(rev):
    r = rev.revisar_palabras([p("estudiiantes")])
    assert r["decision"] == "CORREGIR" and r["faltas"][0]["sugerencias"][0] == "estudiantes"


def test_tilde_omitida(rev):
    f = rev.revisar_palabras([p("inscripcion")])["faltas"]
    assert f and f[0]["tipo"] == "tilde" and f[0]["sugerencias"][0] == "inscripción"


def test_mayuscula_se_respeta(rev):
    assert rev.revisar_palabras([p("Estudiiantes")])["faltas"][0]["sugerencias"][0] == "Estudiantes"


def test_baja_confianza_es_dudosa_no_falta(rev):
    r = rev.revisar_palabras([p("proyetos", conf=20)])
    assert not r["faltas"] and r["dudosas"] and r["decision"] == "REVISION_MANUAL"


def test_palabras_cortas_se_ignoran(rev):
    assert rev.revisar_palabras([p("xq")])["resumen"]["palabras_revisadas"] == 0


def test_numeros_y_signos_se_ignoran(rev):
    r = rev.revisar_palabras([p("2026"), p("---")])
    # no hay texto revisable: la regla de negocio pide que una persona mire la imagen
    assert r["resumen"]["palabras_revisadas"] == 0 and r["decision"] == "REVISION_MANUAL"


def test_cada_falta_trae_motivo_y_caja(rev):
    f = rev.revisar_palabras([p("proyectoss")])["faltas"][0]
    assert f["motivo"] and set(f["caja"]) == {"x", "y", "ancho", "alto"}


def test_imagen_real_sin_faltas(img_limpia):
    r = RevisorOrtografico.cargar().revisar(img_limpia)
    assert r["decision"] == "APROBAR"


def test_imagen_real_con_falta(img_con_falta):
    ruta, fila = img_con_falta
    r = RevisorOrtografico.cargar().revisar(ruta)
    assert r["decision"] != "APROBAR" and r["resumen"]["faltas"] >= 1
