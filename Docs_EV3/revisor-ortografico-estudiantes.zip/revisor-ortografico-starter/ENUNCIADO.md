# EP3 · Guia del equipo: sistema de revision ortografica de piezas graficas

Este paquete trae **solo el modelo**. Todo lo demas lo construyen ustedes. La nota depende de lo que *ustedes* disenan,
configuran y miden, no de que el modelo funcione (eso ya viene hecho).

## 1. El caso (resumen)
La Direccion de Comunicaciones revisa a mano afiches y banners antes de publicarlos. Necesita un sistema que reciba la imagen,
lea su texto y diga: **APROBAR** (se puede publicar), **CORREGIR** (hay faltas) o **REVISION_MANUAL** (no se leyo con seguridad).
Debe explicar *por que* marco cada palabra.

```
Dashboard  -->  API REST (ustedes)  -->  Modelo (viene hecho)
                  ^ aqui estan la seguridad, las pruebas y la nota
```

## 2. Lo que viene hecho
- `modelo/`: el modelo entrenado. `app/modelo.py` y `app/servidor_modelo.py`: lo cargan y lo sirven.
- `Dockerfile.modelo`: contenedor listo. Expone `GET /ping` y `POST /invocations` en el puerto **8080** (mismo contrato que Amazon SageMaker).
- `datos/`: 160 imagenes con sus etiquetas. `entrenamiento/` y `resultados/`: como se entreno y como se evaluo.
- `pruebas/test_modelo.py`: pruebas del modelo, como ejemplo de estilo.
- `verificar_contrato.py`: revisa que su API cumple el contrato de la seccion 4.

> **Proyecto de ejemplo resuelto:** junto a este paquete reciben `ejemplo-triage-de-mensajes.zip`, con los mismos 7 hitos aplicados a otra tematica
> (clasificar la urgencia de mensajes de clientes). Lean su `PASO_A_PASO.md` antes de empezar. No es para copiar: sirve para ver como queda cada hito terminado.

## 3. Lo que deben construir (entregable)
Informe tecnico en PDF (10 paginas) + repositorio GitHub (README, codigo, Dockerfile) + sistema funcionando. Archivo `EP3_Equipo[N]_Apellidos.pdf`.

| Indicador | Que deben hacer | Evidencia |
|---|---|---|
| IE1 | Levantar el modelo en contenedor y consumirlo por su endpoint | `docker compose ps`, llamada a `/invocations` |
| IE2 | Dashboard (Streamlit) que consume **su** API y muestra decision, palabras marcadas, sugerencia y motivo | Capturas |
| IE4 | Escalar con replicas y medir 1 vs 2 vs 3. Calcular en papel cuanto costaria en AWS SageMaker (calculadora de precios de AWS, no necesita cuenta) | Tabla de resultados + tabla de costos |
| IE5 | Servidor, modelo, dataset y dashboard operativos juntos con `docker compose` | Captura de todo arriba |
| IE7 | API REST propia con **clave**, **rate limiting**, validaciones, **Swagger** y **TLS** (https) | `verificar_contrato.py` + diagrama de secuencia |
| IE10 | Minimo 10 casos de prueba, prueba de carga (Locust o JMeter), latencia p50/p95/p99, throughput, tasa de error, y accuracy/precision/recall/F1 del modelo | Reportes y analisis |

Ademas: referencias APA (minimo 2), declaracion de uso de IA, y la retroalimentacion de entregas anteriores incorporada.

## 4. Contrato de la API (lo que su API debe cumplir)
| Ruta | Clave | Respuesta |
|---|---|---|
| `GET /salud` | no | 200 |
| `GET /openapi.json` y `/docs` | no | 200 (Swagger) |
| `POST /v1/revisiones` (campo de archivo `archivo`, PNG o JPEG) | si, encabezado `X-API-Key` | 200 con el JSON de abajo |
| `GET /v1/revisiones` | si | 200, lista del historial reciente |
| `GET /v1/metricas` | si | 200, con `latencia_ms: {p50, p95, p99}` |

Codigos de error: sin clave o clave mala **401** · tipo de archivo no soportado **415** · archivo que no es imagen **400** · sin archivo **422** ·
imagen de mas de 5 MB **413** · demasiadas solicitudes por minuto **429** · el modelo no responde **502**.

Respuesta de `POST /v1/revisiones`: todos los campos que devuelve el modelo (`decision`, `motivo_decision`, `resumen`, `faltas`, `dudosas`,
`texto_detectado`...) mas `id` y `latencia_ms`. Cada elemento de `faltas` trae `palabra`, `sugerencias`, `motivo` y `caja`.

## 5. Ruta sugerida (hitos). Vayan confirmando cada uno
**Hito 1 · Conocer el modelo (30 min).** Instalen Docker Desktop. En la carpeta del proyecto: `docker compose up --build`.
Prueben `http://localhost:8080/ping`. Envien una imagen con curl (`curl -X POST --data-binary "@datos/imagenes/img_000.png" -H "Content-Type: image/png" http://localhost:8080/invocations`).
Lean el JSON: ¿que significa cada campo? Abran `resultados/evaluacion.json` y expliquen las metricas.
*Pista si falla `apt-get` con error 403: la red bloquea http hacia Debian; ya viene resuelto con https. Prueben otra red.*

**Hito 2 · Su API (IE7).** FastAPI es lo mas rapido (Swagger sale solo). Pasos: ruta `/salud` → ruta `/v1/revisiones` que reenvia la imagen al modelo (`http://modelo:8080/invocations`) →
clave en `X-API-Key` (comparen con `secrets.compare_digest`) → validaciones (tipo, tamano, imagen valida) → rate limiting → historial y metricas.
Corran `python verificar_contrato.py --url http://localhost:8000 --clave SU_CLAVE --limite SU_LIMITE` hasta que todo salga OK.
*Pregunta para el informe: ¿por que la clave no debe ir en el codigo ni en el repositorio?*

**Hito 3 · TLS y balanceo (IE7, IE4).** Pongan un gateway delante de la API (nginx, Caddy o Traefik) que termine https con un certificado autofirmado y reparta entre replicas.
Verifiquen con `curl -k https://localhost:8443/salud`. *Pregunta: ¿que cambia con un certificado emitido por una CA real?*

**Hito 4 · Dashboard (IE2).** Streamlit: subir imagen, mostrar el semaforo (verde/amarillo/rojo), dibujar cajas sobre la imagen con las coordenadas de `caja`, y una tabla con palabra, sugerencia y motivo.
Debe llamar a **su API**, nunca al modelo directo.

**Hito 5 · Escala y carga (IE4, IE10).** `docker compose up --scale modelo=2 --scale api=2` (y 3). Escriban un `locustfile.py` que suba imagenes.
Midan p50, p95, p99, throughput y errores con 1, 2 y 3 replicas. Evidencia de recursos: `docker stats`. ¿Escala bien? ¿Donde esta el cuello de botella?
*Cuidado: con varias replicas de la API, cada una lleva su propio contador de limite y de metricas. Expliquen que problema es ese y como se resolveria.*

**Hito 6 · Pruebas y calidad (IE10).** Minimo 10 casos de prueba con pytest: con falta, sin falta, tilde omitida, imagen borrosa, archivo invalido, sin clave, etc.
Calculen accuracy, precision, recall y F1 con las imagenes de `datos/` (partan de `entrenamiento/evaluar.py`) y expliquen por que precision y recall importan mas que accuracy aqui.
Propongan una mejora medida (por ejemplo, ajustar un hiperparametro y comparar).

**Hito 7 · Costos y defensa (IE4, IE6).** Calculen en papel el costo mensual en AWS (endpoint en tiempo real vs serverless) y comparenlo con Docker local.
Preparen 6 laminas: caso y arquitectura · plataforma y costos · demo · decisiones de integracion · pruebas y optimizacion · limites y mejoras.

## 6. Demostracion en vivo (15 minutos)
Todo debe estar corriendo antes de empezar. Muestren: `docker compose ps`; una pieza con faltas y otra limpia en el dashboard; una llamada con curl o Postman a su API por https;
una llamada sin clave que es rechazada; el reporte de carga; `docker stats`. Lleven una pieza con una falta que el modelo **no** detecta (por ejemplo "casa" por "caza") y expliquen por que.

## 7. Limites del modelo (para que no los sorprendan)
- Detecta no-palabras y tildes omitidas; **no** detecta errores que forman otra palabra valida.
- Las metricas del dataset son optimistas: faltas inyectadas, texto limpio, misma familia de fuentes.
- El OCR confunde letras parecidas (l/I) en imagenes borrosas; por eso existe la decision REVISION_MANUAL.
- Vocabulario de la libreria `wordfreq` (CC BY-SA 4.0): citenla.

## 8. Reglas
Pueden usar IA, pero deben **declararlo** y entender lo que entregan: en la defensa se les pedira explicar y modificar su codigo.
Cambien la clave de prueba (`clave-de-prueba`). No suban claves al repositorio.
