"""Servidor del modelo con el contrato de SageMaker: GET /ping y POST /invocations (JSON {"texto": "..."}) en el puerto 8080."""
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from app.modelo import Triage

_modelo = None


def modelo():
    global _modelo
    if _modelo is None:
        _modelo = Triage.cargar()
    return _modelo


@asynccontextmanager
async def vida(_):
    modelo()  # carga al arrancar
    yield


app = FastAPI(title="Modelo de triage", docs_url=None, redoc_url=None, lifespan=vida)


class Entrada(BaseModel):
    texto: str = Field(min_length=1, max_length=2000)


@app.get("/ping")
def ping():
    modelo()
    return {"estado": "ok"}


@app.post("/invocations")
def invocar(e: Entrada):
    return JSONResponse(modelo().predecir(e.texto))
