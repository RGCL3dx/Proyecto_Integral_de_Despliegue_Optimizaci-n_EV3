"""Prueba de carga.  locust -f pruebas/locustfile.py --host https://localhost:8443 --headless -u 20 -r 2 -t 1m --csv resultados/carga"""
import os
import random

from locust import HttpUser, between, task

CLAVE = {"X-API-Key": os.getenv("API_KEY", "clave-de-prueba")}
MENSAJES = ["urgente me cobraron dos veces", "hola cual es el horario", "mi pedido llego roto", "gracias por la atencion",
            "no puedo pagar, la pagina se cae", "quiero cotizar una compra por mayor"]


class Cliente(HttpUser):
    wait_time = between(0.2, 1)

    def on_start(self):
        self.client.verify = False  # certificado autofirmado

    @task(8)
    def clasificar(self):
        self.client.post("/v1/mensajes", json={"texto": random.choice(MENSAJES)}, headers=CLAVE, name="POST /v1/mensajes")

    @task(1)
    def salud(self):
        self.client.get("/salud", name="GET /salud")
