#!/bin/sh
# Genera un certificado AUTOFIRMADO la primera vez (sirve para la prueba; en produccion se usa uno emitido por una CA).
set -e
mkdir -p /etc/nginx/certs
if [ ! -f /etc/nginx/certs/servidor.crt ]; then
  openssl req -x509 -nodes -newkey rsa:2048 -days 365 -subj "/CN=localhost" \
    -addext "subjectAltName=DNS:localhost,IP:127.0.0.1" \
    -keyout /etc/nginx/certs/servidor.key -out /etc/nginx/certs/servidor.crt
  echo "Certificado autofirmado creado."
fi
