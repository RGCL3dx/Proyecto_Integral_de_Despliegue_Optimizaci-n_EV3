"""
Revisa que TU API cumple el contrato del ENUNCIADO.md. No prueba tu codigo: llama a tu API como lo haria otro sistema.

  python verificar_contrato.py --url https://localhost:8443 --clave MI_CLAVE
  python verificar_contrato.py --url http://localhost:8000 --clave MI_CLAVE --limite 20   (si tu limite es 20 por minuto)

Necesita:  pip install requests
Cada linea dice OK o FALLA y por que. Guarda la salida como evidencia para el informe (IE7, IE10).
"""
import argparse
import io
import sys
from pathlib import Path

import requests
import urllib3

urllib3.disable_warnings()  # certificado autofirmado de la prueba local
RAIZ = Path(__file__).resolve().parent
resultados = []


def chequear(nombre, condicion, detalle=""):
    resultados.append(condicion)
    print(("OK    " if condicion else "FALLA ") + nombre + ("" if condicion else f"   -> {detalle}"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", required=True)
    ap.add_argument("--clave", required=True)
    ap.add_argument("--limite", type=int, default=0, help="tu limite de solicitudes por minuto (0 = no probar 429)")
    a = ap.parse_args()
    u, h = a.url.rstrip("/"), {"X-API-Key": a.clave}
    S = lambda m, p, **k: requests.request(m, u + p, timeout=60, verify=False, **k)  # noqa: E731
    png = sorted((RAIZ / "datos" / "imagenes").glob("*.png"))[0]
    datos = png.read_bytes()

    try:
        r = S("GET", "/salud")
    except requests.RequestException:
        sys.exit(f"No pude conectarme a {u}. Revisa que tu API este levantada y que la URL y el puerto sean correctos.")
    chequear("GET /salud responde 200 sin clave", r.status_code == 200, r.status_code)
    chequear("GET /openapi.json (Swagger) publicado", S("GET", "/openapi.json").status_code == 200)
    chequear("POST /v1/revisiones sin clave -> 401", S("POST", "/v1/revisiones", files={"archivo": ("a.png", datos, "image/png")}).status_code == 401)
    chequear("clave incorrecta -> 401", S("POST", "/v1/revisiones", headers={"X-API-Key": "mala"}, files={"archivo": ("a.png", datos, "image/png")}).status_code == 401)
    chequear("archivo de tipo no soportado -> 415", S("POST", "/v1/revisiones", headers=h, files={"archivo": ("a.txt", b"hola", "text/plain")}).status_code == 415)
    chequear("archivo que no es imagen -> 400", S("POST", "/v1/revisiones", headers=h, files={"archivo": ("a.png", b"no soy imagen", "image/png")}).status_code == 400)
    chequear("sin archivo -> 422", S("POST", "/v1/revisiones", headers=h).status_code == 422)
    grande = b"\x89PNG" + b"0" * (6 * 1024 * 1024)
    chequear("imagen de mas de 5 MB -> 413", S("POST", "/v1/revisiones", headers=h, files={"archivo": ("g.png", grande, "image/png")}).status_code == 413)

    r = S("POST", "/v1/revisiones", headers=h, files={"archivo": (png.name, datos, "image/png")})
    chequear("imagen valida -> 200", r.status_code == 200, r.status_code)
    if r.status_code == 200:
        j = r.json()
        for campo in ("id", "decision", "motivo_decision", "resumen", "faltas", "dudosas", "latencia_ms"):
            chequear(f"respuesta incluye '{campo}'", campo in j, "falta el campo")
        chequear("decision es APROBAR, CORREGIR o REVISION_MANUAL", j.get("decision") in ("APROBAR", "CORREGIR", "REVISION_MANUAL"), j.get("decision"))
        if j.get("faltas"):
            f = j["faltas"][0]
            chequear("cada falta trae palabra, sugerencias, motivo y caja", all(k in f for k in ("palabra", "sugerencias", "motivo", "caja")), list(f))

    r = S("GET", "/v1/revisiones", headers=h)
    chequear("GET /v1/revisiones (historial) -> 200 y lista", r.status_code == 200 and isinstance(r.json(), list), r.status_code)
    r = S("GET", "/v1/metricas", headers=h)
    chequear("GET /v1/metricas -> 200", r.status_code == 200, r.status_code)
    if r.status_code == 200:
        m = r.json().get("latencia_ms", {})
        chequear("metricas incluyen latencia p50, p95 y p99", all(k in m for k in ("p50", "p95", "p99")), m)

    if a.limite:
        codigos = [S("GET", "/v1/revisiones", headers=h).status_code for _ in range(a.limite + 5)]
        chequear(f"al pasar {a.limite} solicitudes en un minuto responde 429", 429 in codigos, "nunca respondio 429")

    ok = sum(resultados)
    print(f"\n{ok} de {len(resultados)} comprobaciones correctas.")
    sys.exit(0 if ok == len(resultados) else 1)


if __name__ == "__main__":
    main()
