# Informe tecnico de ejemplo (esqueleto con contenido de muestra)
*EP3_Equipo[N]_Apellidos.pdf, 10 paginas. Aqui solo se muestra que va en cada seccion y con que nivel de detalle.*

## 1. Resumen (media pagina)
El sistema clasifica la urgencia de mensajes de clientes. Corre en Docker (modelo, API, gateway con https y dashboard). La API exige clave, limita solicitudes y publica Swagger. Con datos de la misma fabrica el modelo obtiene F1 = 1,0, pero con mensajes escritos a mano acierta 7 de 14 y deriva 6 a revision manual; el equipo concluye que necesita datos mas variados.

## 2. Modelo y datos (IE1)
- Tipo: TF-IDF + regresion logistica (scikit-learn). Datos: 600 mensajes sinteticos (360 train, 240 test) + 14 manuales.
- Hiperparametros: `ngram_range=(1,2)`, `min_df=2`, `C=3,0`; umbrales de decision 0,65 y 0,35.
- *Captura:* `docker compose ps` y respuesta de `/invocations`.

## 3. API y seguridad (IE7)
- Tabla de endpoints (ruta, metodo, clave, codigos).
- Diagrama de secuencia: Dashboard -> Gateway/API -> Modelo -> API -> Dashboard.
- Seguridad: clave (`secrets.compare_digest`), limite 60/min por clave (429), validacion (422), TLS en el gateway (certificado autofirmado: explicar la diferencia con uno real), cuerpo maximo 10 KB.
- *Captura:* Swagger y salida de `verificar_contrato.py` (17 de 17).

## 4. Dashboard e interpretabilidad (IE2)
- Capturas: caso urgente (rojo), normal (verde), dudoso (amarillo).
- Como la explicacion (palabras con peso) ayuda a quien decide, y su limite: el peso describe al modelo, no prueba que el mensaje sea realmente urgente.

## 5. Infraestructura, escala y costos (IE4, IE5)
- Servicios en `docker-compose.yml`, recursos con `docker stats`.
- Tabla de 1, 2 y 3 replicas (p50/p95/p99, req/s, % errores) y conclusion.
- Costos en papel: supuestos (mensajes/mes, instancia), resultado para SageMaker tiempo real vs serverless vs Docker local, y recomendacion.
- Muestra de medicion sin Docker (un solo proceso, 20 usuarios, 20 s): POST /v1/mensajes mediana 4 ms, p95 12 ms, p99 40 ms, 0 % de errores. Ustedes deben medir con **Docker** y sus replicas.

## 6. Pruebas y calidad (IE10)
- Tabla de los 14 casos (nombre, entrada, esperado, resultado).
- Metricas del modelo: matriz de confusion, accuracy, precision, recall y F1 en test; resultado en mensajes manuales; analisis del error grave.
- Mejora medida: que cambiaron, metrica antes y despues.

## 7. Limites y mejoras
Datos sinteticos, vocabulario pequeno, replicas con contadores separados, certificado autofirmado. Mejoras: datos reales anonimizados, contador de limite compartido (Redis), certificado real, monitoreo.

## 8. Referencias (APA, minimo 2) y declaracion de uso de IA
