# Starter EP3: modelo de revision ortografica
Empiecen leyendo **ENUNCIADO.md**. Comando inicial (PowerShell, dentro de esta carpeta): `docker compose up --build`
Instalar solo si lo necesitan en su PC: Docker Desktop, Python 3.11+, Git.
