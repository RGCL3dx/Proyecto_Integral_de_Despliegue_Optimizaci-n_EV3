"""14 casos de prueba: 6 del modelo y 8 de la API. Cada nombre dice que caso cubre."""
import pytest
from fastapi.testclient import TestClient

from app.api import BackendLocal, crear_app
from app.modelo import Triage

CLAVE = {"X-API-Key": "k"}


@pytest.fixture(scope="module")
def modelo():
    return Triage.cargar()


@pytest.fixture(scope="module")
def cliente():
    return TestClient(crear_app(BackendLocal(), "k", limite_por_minuto=1000))


# --- modelo ---
def test_caso_urgente_se_escala(modelo):
    assert modelo.predecir("urgente me cobraron dos veces la compra")["decision"] == "ESCALAR"


def test_consulta_simple_va_al_flujo_normal(modelo):
    assert modelo.predecir("hola cual es el horario de atencion de la tienda")["decision"] == "RESPONDER_NORMAL"


def test_mensaje_ambiguo_va_a_revision_manual(modelo):
    assert modelo.predecir("mi pedido no llega")["decision"] == "REVISION_MANUAL"


def test_la_explicacion_trae_palabras_y_motivo(modelo):
    r = modelo.predecir("urgente me cobraron dos veces la compra")
    assert r["palabras_clave"] and r["motivo"]


def test_probabilidad_entre_0_y_1(modelo):
    assert 0 <= modelo.predecir("gracias por todo")["probabilidad_alta"] <= 1


def test_texto_con_mayusculas_y_tildes_no_rompe(modelo):
    assert modelo.predecir("ÚRGENTE!!! Me cobraron DOS veces")["decision"] in ("ESCALAR", "REVISION_MANUAL")


# --- API ---
def test_salud_sin_clave(cliente):
    assert cliente.get("/salud").status_code == 200


def test_sin_clave_401(cliente):
    assert cliente.post("/v1/mensajes", json={"texto": "hola"}).status_code == 401


def test_clave_mala_401(cliente):
    assert cliente.post("/v1/mensajes", json={"texto": "hola"}, headers={"X-API-Key": "x"}).status_code == 401


def test_mensaje_valido_200(cliente):
    r = cliente.post("/v1/mensajes", json={"texto": "urgente no puedo pagar"}, headers=CLAVE)
    assert r.status_code == 200 and {"id", "decision", "motivo", "latencia_ms"} <= set(r.json())


def test_texto_vacio_422(cliente):
    assert cliente.post("/v1/mensajes", json={"texto": ""}, headers=CLAVE).status_code == 422


def test_cuerpo_sin_texto_422(cliente):
    assert cliente.post("/v1/mensajes", json={}, headers=CLAVE).status_code == 422


def test_rate_limit_429():
    c = TestClient(crear_app(BackendLocal(), "k", limite_por_minuto=3))
    codigos = [c.get("/v1/mensajes", headers=CLAVE).status_code for _ in range(5)]
    assert codigos == [200, 200, 200, 429, 429]


def test_metricas_con_percentiles(cliente):
    cliente.post("/v1/mensajes", json={"texto": "gracias"}, headers=CLAVE)
    m = cliente.get("/v1/metricas", headers=CLAVE).json()
    assert m["latencia_ms"]["p99"] >= m["latencia_ms"]["p50"] and m["solicitudes_ok"] >= 1
