"""Modelo de triage: TF-IDF + regresion logistica. Explica su decision con las palabras que mas pesaron."""
from __future__ import annotations

import os
from pathlib import Path

import joblib

UMBRAL_ALTO, UMBRAL_BAJO = 0.65, 0.35  # sobre la probabilidad de ALTA


class Triage:
    def __init__(self, vectorizador, clasificador):
        self.vec, self.clf = vectorizador, clasificador
        self.palabras = self.vec.get_feature_names_out()

    @classmethod
    def cargar(cls, carpeta=None):
        carpeta = Path(carpeta or os.getenv("MODEL_DIR") or Path(__file__).resolve().parent.parent / "modelo")
        d = joblib.load(carpeta / "modelo.joblib")
        return cls(d["vectorizador"], d["clasificador"])

    def predecir(self, texto: str) -> dict:
        x = self.vec.transform([texto])
        p_alta = float(self.clf.predict_proba(x)[0][list(self.clf.classes_).index("ALTA")])
        if p_alta >= UMBRAL_ALTO:
            decision, prioridad = "ESCALAR", "ALTA"
        elif p_alta <= UMBRAL_BAJO:
            decision, prioridad = "RESPONDER_NORMAL", "NORMAL"
        else:
            decision, prioridad = "REVISION_MANUAL", "INCIERTA"
        # explicacion: peso de cada palabra presente = coeficiente * valor tf-idf (positivo empuja hacia ALTA)
        coef = self.clf.coef_[0] if self.clf.classes_[1] == "ALTA" else -self.clf.coef_[0]
        fila = x.tocoo()
        aportes = sorted(({"palabra": str(self.palabras[j]), "peso": round(float(coef[j] * v), 3)}
                          for j, v in zip(fila.col, fila.data)), key=lambda a: -abs(a["peso"]))[:5]
        if decision == "REVISION_MANUAL":
            motivo = f"El modelo no esta seguro (probabilidad de ALTA {p_alta:.0%}). Una persona debe leerlo."
        else:
            claves = ", ".join(a["palabra"] for a in aportes if (a["peso"] > 0) == (prioridad == "ALTA"))[:80]
            motivo = f"Probabilidad de ALTA {p_alta:.0%}. Pesaron: {claves or 'sin palabras destacadas'}."
        return {"prioridad": prioridad, "decision": decision, "probabilidad_alta": round(p_alta, 3),
                "palabras_clave": aportes, "motivo": motivo}
