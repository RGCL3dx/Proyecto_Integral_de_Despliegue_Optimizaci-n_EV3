# Ejemplo resuelto (otra tematica). Empiecen por PASO_A_PASO.md
Comando: `docker compose up --build` (PowerShell, dentro de esta carpeta). API: https://localhost:8443/docs · Dashboard: http://localhost:8501 · clave: `clave-de-prueba`.
Probado sin Docker: modelo, API, pruebas (14), verificador de contrato (17 de 17), Locust. **Los Dockerfiles, el gateway y el compose de este ejemplo no se probaron.**
