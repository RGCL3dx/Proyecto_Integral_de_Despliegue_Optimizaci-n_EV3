"""
API REST del ejemplo. Seguridad y operacion se configuran por variables de entorno:
  API_KEY, LIMITE_POR_MINUTO, BACKEND (local | http), MODELO_URL.
El TLS (https) lo entrega el gateway (nginx), no esta API.
"""
import os
import secrets
import time
import uuid
from collections import defaultdict, deque
from datetime import datetime, timezone

from fastapi import Depends, FastAPI, HTTPException, Request
from pydantic import BaseModel, Field

MAX_BYTES = 10_000


class Mensaje(BaseModel):
    texto: str = Field(min_length=1, max_length=2000, description="Mensaje del cliente", examples=["Me cobraron dos veces, es urgente"])


class BackendLocal:
    nombre = "local"

    def __init__(self):
        from app.modelo import Triage
        self.m = Triage.cargar()

    def predecir(self, texto):
        return self.m.predecir(texto)


class BackendHttp:
    nombre = "http"

    def __init__(self, url):
        self.url = url.rstrip("/")

    def predecir(self, texto):
        import requests
        r = requests.post(f"{self.url}/invocations", json={"texto": texto}, timeout=30)
        r.raise_for_status()
        return r.json()


def percentil(vals, p):
    if not vals:
        return 0.0
    v = sorted(vals)
    return round(v[min(len(v) - 1, int(round(p / 100 * (len(v) - 1))))], 1)


def crear_app(backend, api_key, limite_por_minuto=60):
    app = FastAPI(title="API de triage de mensajes", version="1.0.0",
                  description="Clasifica la urgencia de mensajes de clientes y explica por que.")
    est = {"ok": 0, "e4": 0, "e5": 0, "lat": deque(maxlen=2000), "hist": deque(maxlen=200), "ventanas": defaultdict(deque)}

    def autenticar(request: Request):
        clave = request.headers.get("x-api-key", "")
        if not secrets.compare_digest(clave.encode(), api_key.encode()):
            est["e4"] += 1
            raise HTTPException(401, "Falta la clave X-API-Key o es incorrecta.")
        v, ahora = est["ventanas"][clave], time.time()
        while v and ahora - v[0] > 60:
            v.popleft()
        if len(v) >= limite_por_minuto:
            est["e4"] += 1
            raise HTTPException(429, "Demasiadas solicitudes.", headers={"Retry-After": "60"})
        v.append(ahora)

    @app.get("/salud", tags=["operacion"])
    def salud():
        return {"estado": "ok", "backend": backend.nombre}

    @app.post("/v1/mensajes", tags=["triage"], summary="Clasificar un mensaje", dependencies=[Depends(autenticar)])
    async def clasificar(request: Request, mensaje: Mensaje):
        if int(request.headers.get("content-length", 0)) > MAX_BYTES:
            est["e4"] += 1
            raise HTTPException(413, "El cuerpo supera 10 KB.")
        t0 = time.perf_counter()
        try:
            res = backend.predecir(mensaje.texto)
        except Exception as e:  # noqa: BLE001
            est["e5"] += 1
            raise HTTPException(502, f"El modelo no respondio: {type(e).__name__}")
        ms = (time.perf_counter() - t0) * 1000
        est["lat"].append(ms)
        est["ok"] += 1
        res = {"id": uuid.uuid4().hex[:12], "fecha": datetime.now(timezone.utc).isoformat(timespec="seconds"),
               "latencia_ms": round(ms, 1), **res}
        est["hist"].appendleft({"id": res["id"], "fecha": res["fecha"], "decision": res["decision"], "texto": mensaje.texto[:60]})
        return res

    @app.get("/v1/mensajes", tags=["triage"], summary="Historial reciente", dependencies=[Depends(autenticar)])
    def historial(limite: int = 20):
        return list(est["hist"])[:max(1, min(limite, 200))]

    @app.get("/v1/metricas", tags=["operacion"], dependencies=[Depends(autenticar)])
    def metricas():
        lat, total = list(est["lat"]), est["ok"] + est["e4"] + est["e5"]
        return {"solicitudes_ok": est["ok"], "errores_4xx": est["e4"], "errores_5xx": est["e5"],
                "tasa_error": round((est["e4"] + est["e5"]) / total, 4) if total else 0.0,
                "latencia_ms": {"p50": percentil(lat, 50), "p95": percentil(lat, 95), "p99": percentil(lat, 99)}}

    return app


def crear_app_desde_entorno():
    b = os.getenv("BACKEND", "local")
    backend = BackendHttp(os.environ["MODELO_URL"]) if b == "http" else BackendLocal()
    return crear_app(backend, os.environ["API_KEY"], int(os.getenv("LIMITE_POR_MINUTO", "60")))
