"""Dashboard (Streamlit). Llama a la API, nunca al modelo.  Variables: API_URL, API_KEY"""
import os

import pandas as pd
import requests
import streamlit as st

API_URL = os.getenv("API_URL", "http://localhost:8000").rstrip("/")
CAB = {"X-API-Key": os.getenv("API_KEY", "clave-de-prueba")}
SEMAFORO = {"ESCALAR": "🔴 ESCALAR al equipo de soporte", "RESPONDER_NORMAL": "🟢 Responder en el flujo normal",
            "REVISION_MANUAL": "🟡 Revision manual: el modelo no esta seguro"}

st.set_page_config(page_title="Triage de mensajes", layout="wide")
st.title("Triage de mensajes de clientes")
texto = st.text_area("Pega el mensaje del cliente", height=120)
if st.button("Clasificar") and texto.strip():
    try:
        r = requests.post(f"{API_URL}/v1/mensajes", json={"texto": texto}, headers=CAB, timeout=30)
    except requests.RequestException as e:
        st.error(f"No se pudo llamar a la API: {e}")
        st.stop()
    if r.status_code != 200:
        st.error(f"La API respondio {r.status_code}: {r.json().get('detail', r.text)}")
        st.stop()
    j = r.json()
    st.subheader(SEMAFORO[j["decision"]])
    st.write(j["motivo"])
    c1, c2 = st.columns(2)
    c1.metric("Probabilidad de urgencia alta", f"{j['probabilidad_alta']:.0%}")
    c2.metric("Latencia (ms)", j["latencia_ms"])
    st.markdown("**Palabras que mas pesaron** (positivo empuja hacia ALTA, negativo hacia NORMAL)")
    df = pd.DataFrame(j["palabras_clave"]).set_index("palabra")
    st.bar_chart(df)
st.markdown("### Historial reciente")
try:
    h = requests.get(f"{API_URL}/v1/mensajes", headers=CAB, timeout=5).json()
    st.dataframe(pd.DataFrame(h), use_container_width=True, hide_index=True) if h else st.info("Sin mensajes aun.")
except requests.RequestException:
    st.info("Historial no disponible.")
