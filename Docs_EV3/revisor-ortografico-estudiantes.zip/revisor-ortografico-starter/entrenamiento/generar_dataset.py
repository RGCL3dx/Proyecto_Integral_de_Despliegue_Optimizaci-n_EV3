"""
Genera el dataset de imagenes del caso: afiches y banners con texto en espanol, algunos con faltas de ortografia
INYECTADAS A PROPOSITO (asi sabemos con certeza donde estan las faltas y podemos calcular precision, recall y F1).

  python entrenamiento/generar_dataset.py --salida datos --cantidad 160 --semilla 7

Produce:
  datos/imagenes/img_000.png ...
  datos/etiquetas.csv   una fila por imagen: particion (train/test), dificultad, palabras con falta y su correccion

LIMITACION IMPORTANTE (para discutir en clase): solo se inyectan faltas que producen una NO-PALABRA
(no estan en un diccionario independiente y son muy poco frecuentes en wordfreq) o una TILDE omitida
en palabras largas. Las faltas que producen otra palabra valida ("casa" por "caza") no las puede detectar
un corrector basado en vocabulario y quedan fuera del dataset. Ademas, el modelo y el dataset usan la misma
familia de fuentes (wordfreq). Por eso las metricas de este dataset son mas optimistas que las de un uso real.
"""
from __future__ import annotations

import argparse
import csv
import random
import re
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont
from spellchecker import SpellChecker
from wordfreq import zipf_frequency

FUENTES = Path(__file__).resolve().parent / "fuentes"

TITULOS = [
    "Matrícula abierta", "Feria de empleo", "Semana de la innovación", "Charla de ciberseguridad",
    "Inscripciones disponibles", "Taller de inteligencia artificial", "Jornada de orientación",
    "Beca de excelencia académica", "Biblioteca abierta", "Ceremonia de titulación", "Campeonato deportivo",
    "Concurso de proyectos", "Noche de talentos", "Seminario de tecnología", "Curso de programación",
    "Exposición de trabajos", "Charla de seguridad", "Programa de práctica profesional",
]
CUERPOS = [
    "Inscríbete hasta el viernes en la sede Concepción", "Revisa la información en nuestro sitio web",
    "Participa y gana premios para tu carrera", "Más de cien empresas estarán presentes",
    "La actividad es gratuita para todos los estudiantes", "Te esperamos en el auditorio principal",
    "Consulta los requisitos con tu coordinador académico", "Trae tu credencial y tu cédula de identidad",
    "Los cupos son limitados, reserva tu lugar", "Aprende con especialistas de la industria",
    "Solicita tu certificado en la secretaría", "Esta semana se realizará la actividad de bienvenida",
    "El plazo de postulación termina pronto", "Conoce las oportunidades de trabajo para ti",
    "Habrá café y una presentación de los proyectos", "Invita a tus compañeros y a tu familia",
]
PIES = [
    "Dirección de comunicaciones", "Más información en la secretaría académica",
    "Cupos limitados por orden de llegada", "Organiza la escuela de informática",
    "Entrada liberada para estudiantes", "Atención de lunes a viernes por la mañana",
]
PAREJAS_COLOR = {  # (fondo, texto) por dificultad
    "facil": [("#FFFFFF", "#111111"), ("#F4EDE0", "#2B2B2B"), ("#0B3D91", "#FFFFFF"), ("#E8F1FB", "#0B2545")],
    "media": [("#FFD60A", "#1A1A1A"), ("#1B5E20", "#F2F2F2"), ("#C9D6DF", "#22303C"), ("#7A1F2B", "#FBEFEF")],
    "dificil": [("#BFC8D0", "#5A6672"), ("#D9C7A0", "#7A5C1E"), ("#3C5A78", "#A9BBCC")],
}
CONFUSIONES = [("b", "v"), ("v", "b"), ("s", "c"), ("c", "s"), ("z", "s"), ("s", "z"), ("ll", "y"), ("y", "ll"),
               ("g", "j"), ("j", "g"), ("c", "k"), ("qu", "k")]
TILDES = {"á": "a", "é": "e", "í": "i", "ó": "o", "ú": "u", "Á": "A", "É": "E", "Í": "I", "Ó": "O", "Ú": "U"}


# ----------------------------------------------------------------------------- inyeccion de faltas
def aplicar(tipo: str, w: str, rng: random.Random) -> str | None:
    if tipo == "tilde":
        pos = [i for i, c in enumerate(w) if c in TILDES]
        if not pos:
            return None
        i = rng.choice(pos)
        return w[:i] + TILDES[w[i]] + w[i + 1:]
    if len(w) < 5:
        return None
    if tipo == "omitir":
        i = rng.randrange(1, len(w) - 1)
        return w[:i] + w[i + 1:]
    if tipo == "duplicar":
        i = rng.randrange(1, len(w) - 1)
        return w[:i] + w[i] + w[i:]
    if tipo == "transponer":
        i = rng.randrange(1, len(w) - 2)
        return w[:i] + w[i + 1] + w[i] + w[i + 2:]
    if tipo == "confusion":
        opciones = [(a, b) for a, b in CONFUSIONES if a in w.lower()]
        if not opciones:
            return None
        a, b = rng.choice(opciones)
        i = w.lower().index(a)
        return w[:i] + b + w[i + len(a):]
    if tipo == "h":
        pos = [i for i, c in enumerate(w) if c.lower() == "h" and (i == 0 or w[i - 1].lower() != "c")]
        if not pos:
            return None
        i = rng.choice(pos)
        return w[:i] + w[i + 1:]
    return None


def es_no_palabra(w: str, diccionario: SpellChecker) -> bool:
    """No esta en el diccionario de pyspellchecker (fuente independiente del modelo) y casi no se usa."""
    return w.lower() not in diccionario and zipf_frequency(w.lower(), "es") < 2.0


def inyectar_falta(w: str, rng: random.Random, diccionario: SpellChecker):
    """Devuelve (palabra_con_falta, tipo) o None.
    - tilde: solo en palabras de 6 o mas letras (evita pares reales como esta/esta con tilde).
    - el resto: exige que el resultado sea una no-palabra."""
    tipos = ["tilde", "tilde", "omitir", "duplicar", "transponer", "confusion", "h"]
    rng.shuffle(tipos)
    for t in tipos:
        nuevo = aplicar(t, w, rng)
        if not nuevo or nuevo.lower() == w.lower():
            continue
        if t == "tilde":
            if len(w) >= 6:
                return nuevo, t
        elif es_no_palabra(nuevo, diccionario):
            return nuevo, t
    return None


def limpiar(palabra: str) -> str:
    """Quita la puntuacion pegada a la palabra ('limitados,' -> 'limitados') para que la etiqueta sea la palabra sola."""
    return re.sub(r"^\W+|\W+$", "", palabra)


# ----------------------------------------------------------------------------- dibujo
def fuente(negrita: bool, tamano: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(str(FUENTES / ("DejaVuSans-Bold.ttf" if negrita else "DejaVuSans.ttf")), tamano)


def envolver(draw, texto, fnt, ancho_max):
    lineas, actual = [], ""
    for palabra in texto.split():
        prueba = (actual + " " + palabra).strip()
        if draw.textlength(prueba, font=fnt) <= ancho_max or not actual:
            actual = prueba
        else:
            lineas.append(actual)
            actual = palabra
    lineas.append(actual)
    return lineas


def renderizar(titulo, cuerpo, pie, dificultad, rng):
    ancho = rng.choice([1000, 1100, 1200])
    tam = {"facil": (58, 38, 28), "media": (50, 32, 24), "dificil": (40, 24, 18)}[dificultad]
    fondo, color = rng.choice(PAREJAS_COLOR[dificultad])
    margen = 60
    medidor = ImageDraw.Draw(Image.new("RGB", (10, 10)))
    bloques = [(l, fuente(True, tam[0])) for l in envolver(medidor, titulo, fuente(True, tam[0]), ancho - 2 * margen)]
    bloques += [("", None)]
    bloques += [(l, fuente(False, tam[1])) for l in envolver(medidor, cuerpo, fuente(False, tam[1]), ancho - 2 * margen)]
    bloques += [("", None)]
    bloques += [(l, fuente(False, tam[2])) for l in envolver(medidor, pie, fuente(False, tam[2]), ancho - 2 * margen)]
    alto = margen * 2 + sum((f.size * 1.5 if f else tam[1] * 0.8) for _, f in bloques)
    img = Image.new("RGB", (ancho, int(alto)), fondo)
    draw = ImageDraw.Draw(img)
    y = margen
    for texto, fnt in bloques:
        if fnt is None:
            y += tam[1] * 0.8
            continue
        draw.text((margen, y), texto, font=fnt, fill=color)
        y += fnt.size * 1.5
    if dificultad != "facil":
        angulo = rng.uniform(-1, 1) if dificultad == "media" else rng.uniform(-4, 4)
        img = img.rotate(angulo, resample=Image.BICUBIC, expand=True, fillcolor=fondo)
        if dificultad == "dificil":
            img = img.filter(ImageFilter.GaussianBlur(1.3))
        px = img.load()
        for _ in range(int(img.width * img.height * (0.01 if dificultad == "media" else 0.06))):
            x, yy = rng.randrange(img.width), rng.randrange(img.height)
            v = rng.randrange(-40, 40)
            r, g, b = px[x, yy]
            px[x, yy] = (max(0, min(255, r + v)), max(0, min(255, g + v)), max(0, min(255, b + v)))
    return img


# ----------------------------------------------------------------------------- programa principal
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--salida", default="datos")
    ap.add_argument("--cantidad", type=int, default=160)
    ap.add_argument("--semilla", type=int, default=7)
    a = ap.parse_args()

    salida = Path(a.salida)
    (salida / "imagenes").mkdir(parents=True, exist_ok=True)
    rng = random.Random(a.semilla)
    diccionario = SpellChecker(language="es")
    filas = []
    for i in range(a.cantidad):
        dificultad = rng.choices(["facil", "media", "dificil"], weights=[4, 4, 2])[0]
        textos = [rng.choice(TITULOS), rng.choice(CUERPOS), rng.choice(PIES)]
        palabras = [w for t in textos for w in t.split()]
        con_errores = rng.random() < 0.55
        errores = []
        if con_errores:
            n = rng.choices([1, 2, 3], weights=[6, 3, 1])[0]
            candidatas = [(k, w) for k, w in enumerate(palabras) if len(w) >= 5]
            rng.shuffle(candidatas)
            usadas = set()
            for k, w in candidatas:
                if len(errores) >= n:
                    break
                if w.lower() in usadas:
                    continue
                r = inyectar_falta(w, rng, diccionario)
                if r:
                    palabras[k] = r[0]
                    usadas.add(w.lower())
                    errores.append((r[0], w, r[1]))
        corto = iter(palabras)
        textos = [" ".join(next(corto) for _ in t.split()) for t in textos]
        img = renderizar(*textos, dificultad, rng)
        nombre = f"img_{i:03d}.png"
        img.save(salida / "imagenes" / nombre, optimize=True)
        filas.append({
            "archivo": nombre,
            "particion": "train" if i % 8 < 5 else "test",
            "dificultad": dificultad,
            "tiene_faltas": int(bool(errores)),
            "palabras_con_falta": "|".join(limpiar(e[0]) for e in errores),
            "palabras_correctas": "|".join(limpiar(e[1]) for e in errores),
            "tipos": "|".join(e[2] for e in errores),
            "texto": " / ".join(textos),
        })
    with open(salida / "etiquetas.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(filas[0]))
        w.writeheader()
        w.writerows(filas)
    n_train = sum(f["particion"] == "train" for f in filas)
    print(f"{len(filas)} imagenes en {salida / 'imagenes'} ({n_train} train, {len(filas) - n_train} test). "
          f"Con faltas: {sum(f['tiene_faltas'] for f in filas)}.")


if __name__ == "__main__":
    main()
