"""Funciones compartidas por entrenar.py y evaluar.py: leer etiquetas, correr el OCR y calcular metricas."""
from __future__ import annotations

import csv
import sys
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from PIL import Image  # noqa: E402

from app.modelo import Palabra, RevisorOrtografico, distancia_edicion, leer_palabras  # noqa: E402


def cargar_etiquetas(datos: str | Path, particion: str) -> list[dict]:
    with open(Path(datos) / "etiquetas.csv", newline="", encoding="utf-8") as f:
        return [fila for fila in csv.DictReader(f) if fila["particion"] == particion]


def ocr_de_todas(filas: list[dict], datos: str | Path, psm: int = 3, idioma: str = "spa",
                 hilos: int = 4) -> dict[str, list[Palabra]]:
    """Corre el OCR una sola vez por imagen (es la parte lenta) para poder probar muchas configuraciones."""
    def una(fila):
        with Image.open(Path(datos) / "imagenes" / fila["archivo"]) as img:
            return fila["archivo"], leer_palabras(img, idioma, psm)
    with ThreadPoolExecutor(hilos) as pool:
        return dict(pool.map(una, filas))


def _prf(tp: int, fp: int, fn: int) -> dict:
    p = tp / (tp + fp) if tp + fp else 0.0
    r = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * p * r / (p + r) if p + r else 0.0
    return {"precision": round(p, 4), "recall": round(r, 4), "f1": round(f1, 4)}


def emparejar(marcadas: list[str], reales: list[str]) -> list[tuple[str, str]]:
    """Une cada palabra marcada con una falta real: primero las identicas y luego las que difieren en 1 letra
    (el OCR confunde l/I, rn/m, etc.: si marco 'Iguar' donde la falta real es 'lguar', encontro la falta correcta)."""
    libres, pares, pendientes = list(reales), [], []
    for m in marcadas:
        if m in libres:
            libres.remove(m)
            pares.append((m, m))
        else:
            pendientes.append(m)
    for m in pendientes:
        cercanas = [r for r in libres if distancia_edicion(m, r) <= 1]
        if cercanas:
            libres.remove(cercanas[0])
            pares.append((m, cercanas[0]))
    return pares


def calcular_metricas(revisor: RevisorOrtografico, filas: list[dict], ocr: dict[str, list[Palabra]],
                      con_sugerencias: bool = False) -> dict:
    """
    Dos niveles de evaluacion:
      - IMAGEN: "se debe detener esta pieza?" (positivo = la decision NO es APROBAR). Aqui hay accuracy,
        precision, recall y F1, porque hay imagenes con y sin faltas en proporciones parecidas.
      - PALABRA: se comparan las palabras marcadas con las faltas reales (como conjuntos de palabras por imagen).
        No se informa accuracy porque casi todas las palabras son correctas (clases desbalanceadas):
        un modelo que nunca marcara nada tendria accuracy alta y seria inutil. Por eso se usan precision, recall y F1.
    """
    grupos = {"todas": filas}
    for dif in ("facil", "media", "dificil"):
        grupos[dif] = [f for f in filas if f["dificultad"] == dif]
    salida = {}
    for nombre, grupo in grupos.items():
        tp = fp = fn = 0
        cm = Counter()
        top1_ok = top1_n = 0
        for fila in grupo:
            res = revisor.revisar_palabras(ocr[fila["archivo"]], con_sugerencias)
            con_falta = [w for w in fila["palabras_con_falta"].lower().split("|") if w]
            correctas = [w for w in fila["palabras_correctas"].lower().split("|") if w]
            par = dict(zip(con_falta, correctas))  # palabra con falta -> como debia escribirse
            marcadas = [f["palabra"].lower() for f in res["faltas"]]
            pares = emparejar(marcadas, con_falta)
            t = len(pares)
            tp, fp, fn = tp + t, fp + len(marcadas) - t, fn + len(con_falta) - t
            if con_sugerencias:
                for f in res["faltas"]:
                    real = next((r for m, r in pares if m == f["palabra"].lower()), None)
                    if real is not None:
                        top1_n += 1
                        top1_ok += bool(f["sugerencias"]) and f["sugerencias"][0].lower() == par[real]
            real_pos = fila["tiene_faltas"] == "1"
            pred_pos = res["decision"] != "APROBAR"
            cm["TP" if real_pos and pred_pos else "FN" if real_pos else "FP" if pred_pos else "TN"] += 1
        n = len(grupo)
        img = {"accuracy": round((cm["TP"] + cm["TN"]) / n, 4) if n else 0.0,
               **_prf(cm["TP"], cm["FP"], cm["FN"]), "matriz": dict(cm), "imagenes": n}
        pal = {**_prf(tp, fp, fn), "tp": tp, "fp": fp, "fn": fn}
        if con_sugerencias:
            pal["sugerencia_top1"] = round(top1_ok / top1_n, 4) if top1_n else 0.0
        salida[nombre] = {"imagen": img, "palabra": pal}
    return salida
