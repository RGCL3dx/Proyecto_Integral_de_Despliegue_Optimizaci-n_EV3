"""
"Entrena" el modelo: construye el vocabulario y busca los mejores hiperparametros con el conjunto TRAIN.

  python entrenamiento/entrenar.py --datos datos --salida modelo

Pasos:
  1. Construye el vocabulario espanol con frecuencias a partir de la libreria wordfreq (CC BY-SA 4.0)
     y le suma el vocabulario de dominio (entrenamiento/vocabulario_dominio.txt).
  2. Corre el OCR sobre las imagenes de la particion "train" (la parte lenta, una sola vez).
  3. Prueba todas las combinaciones de hiperparametros (busqueda en grilla) y se queda con la de mayor F1
     a nivel de palabra (desempata con el F1 a nivel de imagen).
  4. Guarda el artefacto del modelo: modelo/modelo.json + modelo/vocabulario.json.gz
     y la tabla completa de la busqueda en resultados/busqueda_hiperparametros.csv

Las metricas finales se miden con la particion "test" usando evaluar.py (nunca se usa test para elegir parametros).
"""
from __future__ import annotations

import argparse
import csv
import itertools
import re
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from comun import calcular_metricas, cargar_etiquetas, ocr_de_todas  # noqa: E402

from app.modelo import PARAMS_DEFECTO, RevisorOrtografico, guardar_modelo  # noqa: E402

RAIZ = Path(__file__).resolve().parent.parent
RE_VALIDA = re.compile(r"^[a-záéíóúüñ]{2,}$")

GRILLA = {
    "umbral_zipf": [1.0, 1.5, 2.0, 2.5, 3.0, 3.5],
    "razon_tilde": [0, 2, 4, 8, 16],
    "conf_ocr_min": [0, 40, 60, 80],
    "largo_minimo": [3, 4],
}


def construir_vocabulario() -> dict[str, int]:
    from wordfreq import get_frequency_dict  # solo se necesita al entrenar, no al servir el modelo
    bruto = get_frequency_dict("es", wordlist="best")
    # frecuencia relativa -> apariciones por mil millones de palabras (Zipf = log10 de este numero)
    return {w: int(f * 1e9) for w, f in bruto.items() if RE_VALIDA.match(w) and f * 1e9 >= 10}


def leer_dominio(ruta: Path) -> list[str]:
    return [l.strip().lower() for l in ruta.read_text(encoding="utf-8").splitlines()
            if l.strip() and not l.startswith("#")]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--datos", default=str(RAIZ / "datos"))
    ap.add_argument("--salida", default=str(RAIZ / "modelo"))
    ap.add_argument("--dominio", default=str(RAIZ / "entrenamiento" / "vocabulario_dominio.txt"))
    ap.add_argument("--psm", type=int, default=PARAMS_DEFECTO["psm"])
    a = ap.parse_args()

    t0 = time.time()
    print("1/4 Construyendo vocabulario...")
    vocab = construir_vocabulario()
    dominio = leer_dominio(Path(a.dominio))
    print(f"    {len(vocab):,} palabras con frecuencia; {len(dominio)} terminos de dominio")

    print("2/4 Leyendo las imagenes de train con OCR (puede tardar un par de minutos)...")
    filas = cargar_etiquetas(a.datos, "train")
    ocr = ocr_de_todas(filas, a.datos, psm=a.psm)
    print(f"    {len(filas)} imagenes procesadas")

    print("3/4 Busqueda de hiperparametros...")
    resultados = []
    for umbral in GRILLA["umbral_zipf"]:
        revisor = RevisorOrtografico(vocab, {**PARAMS_DEFECTO, "umbral_zipf": umbral, "psm": a.psm}, dominio)
        for razon, conf, largo in itertools.product(GRILLA["razon_tilde"], GRILLA["conf_ocr_min"], GRILLA["largo_minimo"]):
            revisor.params.update({"razon_tilde": razon, "conf_ocr_min": conf, "largo_minimo": largo})
            m = calcular_metricas(revisor, filas, ocr)["todas"]
            resultados.append({"umbral_zipf": umbral, "razon_tilde": razon, "conf_ocr_min": conf, "largo_minimo": largo,
                               "f1_palabra": m["palabra"]["f1"], "precision_palabra": m["palabra"]["precision"],
                               "recall_palabra": m["palabra"]["recall"], "f1_imagen": m["imagen"]["f1"],
                               "accuracy_imagen": m["imagen"]["accuracy"]})
    resultados.sort(key=lambda r: (r["f1_palabra"], r["f1_imagen"]), reverse=True)
    mejor = resultados[0]
    Path(RAIZ / "resultados").mkdir(exist_ok=True)
    with open(RAIZ / "resultados" / "busqueda_hiperparametros.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(resultados[0]))
        w.writeheader()
        w.writerows(resultados)

    params = {**PARAMS_DEFECTO, "psm": a.psm,
              **{k: mejor[k] for k in ("umbral_zipf", "razon_tilde", "conf_ocr_min", "largo_minimo")}}
    # distancia_max solo afecta a las sugerencias: se elige mirando la exactitud de la sugerencia (top-1) en train
    mejores_sug = {}
    for d in (1, 2):
        rev = RevisorOrtografico(vocab, {**params, "distancia_max": d}, dominio)
        mejores_sug[d] = calcular_metricas(rev, filas, ocr, con_sugerencias=True)["todas"]["palabra"].get("sugerencia_top1", 0)
    params["distancia_max"] = 2 if mejores_sug[2] > mejores_sug[1] else 1

    final = RevisorOrtografico(vocab, params, dominio)
    metricas_train = calcular_metricas(final, filas, ocr, con_sugerencias=True)["todas"]
    print("4/4 Guardando el modelo...")
    guardar_modelo(a.salida, vocab, params, dominio, metricas={"train": metricas_train},
                   extra_meta={"vocabulario": "wordfreq (CC BY-SA 4.0)", "imagenes_train": len(filas),
                               "busqueda": f"{len(resultados)} combinaciones"})
    print("\nMejores hiperparametros:", {k: params[k] for k in ("umbral_zipf", "razon_tilde", "conf_ocr_min", "largo_minimo", "distancia_max")})
    print("Metricas en TRAIN (optimistas, se usaron para elegir):")
    print("   palabra:", metricas_train["palabra"])
    print("   imagen: ", {k: v for k, v in metricas_train["imagen"].items() if k != "matriz"})
    print(f"\nModelo guardado en {a.salida}  ({time.time() - t0:.0f} s). Ahora ejecuta evaluar.py para medir en TEST.")


if __name__ == "__main__":
    main()
