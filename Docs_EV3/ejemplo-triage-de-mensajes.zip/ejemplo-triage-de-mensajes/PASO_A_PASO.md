# Ejemplo resuelto: triage de mensajes de clientes

**Para que lo usan:** para ver como queda cada hito terminado. **No es para copiar**: su caso (revision ortografica de imagenes) tiene otro modelo, otros datos y otro contrato de API.

**El caso del ejemplo:** una tienda en linea recibe mensajes de clientes. Un modelo decide si el mensaje es urgente (**ESCALAR**), normal (**RESPONDER_NORMAL**) o dudoso (**REVISION_MANUAL**) y explica con las palabras que mas pesaron.

```
Dashboard (:8501) --> API REST (:8000) --> Modelo (:8080)
curl / Postman / Locust --https:8443--> Gateway (nginx) --> API --> Modelo
```

Comandos en PowerShell, dentro de esta carpeta. Cada hito termina con una **comprobacion**.

## Hito 1 · Levantar y conocer el modelo
1. `docker compose up --build modelo`
2. En otra terminal: `curl http://localhost:8080/ping` debe responder `{"estado":"ok"}`.
   (En PowerShell real use `curl.exe`, porque `curl` es un alias de otra cosa.)
3. Probar el modelo: `curl.exe -X POST http://localhost:8080/invocations -H "Content-Type: application/json" -d "{\"texto\":\"urgente me cobraron dos veces\"}"`
4. Leer el JSON: `decision`, `probabilidad_alta`, `palabras_clave` (el peso positivo empuja hacia ALTA) y `motivo`.
5. Abrir `resultados/evaluacion.json` y explicar cada numero (ver "Metricas" mas abajo).

**Comprobacion:** `/ping` responde y el modelo devuelve decision para un mensaje.
**Tipo de modelo (para el informe):** TF-IDF de 1 a 2 palabras + regresion logistica (scikit-learn). Se entrena con `entrenamiento/entrenar.py`; hiperparametros: `ngram_range`, `min_df`, `C`.

## Hito 2 · La API (`app/api.py`)
Se construyo en este orden, probando cada pieza antes de seguir:
1. `GET /salud`.
2. `POST /v1/mensajes` que recibe `{"texto": "..."}` y llama al modelo.
3. Clave en el encabezado `X-API-Key`, comparada con `secrets.compare_digest` (si no, un atacante podria adivinarla midiendo tiempos).
4. Validacion: texto vacio o ausente -> 422 (lo hace `pydantic`, con `Field(min_length=1)`).
5. Limite de solicitudes por minuto -> 429.
6. Historial y metricas (`/v1/mensajes`, `/v1/metricas` con p50/p95/p99).
7. Swagger: sale solo en `/docs`.

Para probar sin Docker: `$env:API_KEY="clave-de-prueba"; $env:BACKEND="local"; uvicorn app.api:crear_app_desde_entorno --factory --port 8000`
**Comprobacion:** `python verificar_contrato.py --url http://localhost:8000 --clave clave-de-prueba --limite 60` -> todo OK (17 de 17 en el ejemplo).

## Hito 3 · Contenedores y https
- Cada servicio tiene su Dockerfile (`Dockerfile.modelo`, `Dockerfile.api`, `Dockerfile.dashboard`) y se unen en `docker-compose.yml`.
- El **gateway** (`gateway/`) es nginx: genera un certificado autofirmado al arrancar, recibe https en el 8443 y reenvia a la API.
- `docker compose up --build`  y luego `curl.exe -k https://localhost:8443/salud` (`-k` acepta el certificado autofirmado).

**Comprobacion:** `docker compose ps` muestra los 4 servicios "running" y el curl por https responde 200.

## Hito 4 · Dashboard (`dashboard/dashboard.py`)
Streamlit: un cuadro de texto, un boton, el semaforo, el motivo, un grafico de barras con el peso de cada palabra y el historial. Llama a la **API**, no al modelo. Abrir `http://localhost:8501`.
**Comprobacion:** un mensaje urgente y uno normal dan semaforos distintos con motivos distintos.

## Hito 5 · Escala y carga
1. `locustfile.py` (en `pruebas/`) manda mensajes variados.
2. Medir: `locust -f pruebas/locustfile.py --host https://localhost:8443 --headless -u 20 -r 5 -t 1m --csv resultados/carga` con `docker compose up --scale modelo=1 --scale api=1`, luego con 2 y con 3.
3. Cada vez: guardar p50, p95, p99, req/s y % de fallas del CSV, y una captura de `docker stats`.
4. Tabla para el informe:

| Replicas (modelo, api) | p50 ms | p95 ms | p99 ms | req/s | % errores | CPU modelo |
|---|---|---|---|---|---|---|
| 1, 1 | (completar) | | | | | |
| 2, 2 | | | | | | |
| 3, 3 | | | | | | |

**Ojo con el limite por minuto:** al escalar la API, cada replica cuenta aparte. Para la prueba de carga suban `LIMITE_POR_MINUTO`.
**Comprobacion:** tienen la tabla completa y una conclusion: ¿cuando agregar replicas deja de servir? ¿donde esta el cuello de botella?

## Hito 6 · Pruebas y calidad (`pruebas/test_triage.py`)
14 casos: urgente, normal, ambiguo, explicacion presente, probabilidad en rango, mayusculas y tildes, salud, sin clave, clave mala, valido, vacio, sin campo, limite 429, metricas. `pytest pruebas -v`.

**Metricas del modelo** (`python entrenamiento/evaluar.py`):
- Con el test de la misma fabrica de datos: accuracy, precision, recall y F1 = 1,0. **Es una alarma, no un premio**: el test usa las mismas plantillas que el entrenamiento.
- Con 14 mensajes escritos a mano (`datos/mensajes_manuales.csv`): 7 aciertos, 6 enviados a revision manual y **1 error grave** (urgente clasificado como normal: "Me enviaron la factura a nombre de otra persona con mis datos").
- Conclusion para el informe: el modelo no generaliza; mejora posible = mas variedad de datos, no solo cambiar `C`. Esa mejora medida (antes/despues) es lo que se pide en IE10/IE11.

## Hito 7 · Costos y defensa
- Costos: en la calculadora de precios de AWS (no necesita cuenta) estimen un endpoint de SageMaker en tiempo real y uno serverless con sus supuestos (solicitudes por mes, tamano de instancia). Comparen con Docker local (costo de su propio computador).
- Defensa: 6 laminas (caso y arquitectura · plataforma y costos · demo · integracion · pruebas y optimizacion · limites). Ensayen la demo completa, incluida una llamada sin clave rechazada.

## Que NO hizo este ejemplo (y ustedes si deben)
- No mide con 1, 2 y 3 replicas (la tabla del hito 5 esta vacia a proposito).
- No incluye la tabla de costos con numeros.
- La API aqui es mas simple: su caso recibe imagenes (`multipart`), tiene mas codigos de error (415, 400, 413) y mas campos.
