"""Comprueba el contrato de la API del ejemplo.  python verificar_contrato.py --url http://localhost:8000 --clave K --limite 20"""
import argparse
import sys

import requests
import urllib3

urllib3.disable_warnings()
res = []


def ok(nombre, cond, det=""):
    res.append(cond)
    print(("OK    " if cond else "FALLA ") + nombre + ("" if cond else f"   -> {det}"))


ap = argparse.ArgumentParser()
ap.add_argument("--url", required=True)
ap.add_argument("--clave", required=True)
ap.add_argument("--limite", type=int, default=0)
a = ap.parse_args()
u, h = a.url.rstrip("/"), {"X-API-Key": a.clave}
S = lambda m, p, **k: requests.request(m, u + p, timeout=30, verify=False, **k)  # noqa: E731
try:
    r = S("GET", "/salud")
except requests.RequestException:
    sys.exit(f"No pude conectarme a {u}. Revisa que la API este levantada.")
ok("GET /salud -> 200 sin clave", r.status_code == 200, r.status_code)
ok("Swagger /openapi.json publicado", S("GET", "/openapi.json").status_code == 200)
ok("sin clave -> 401", S("POST", "/v1/mensajes", json={"texto": "hola"}).status_code == 401)
ok("clave mala -> 401", S("POST", "/v1/mensajes", json={"texto": "hola"}, headers={"X-API-Key": "mala"}).status_code == 401)
ok("texto vacio -> 422", S("POST", "/v1/mensajes", json={"texto": ""}, headers=h).status_code == 422)
ok("sin campo texto -> 422", S("POST", "/v1/mensajes", json={}, headers=h).status_code == 422)
r = S("POST", "/v1/mensajes", json={"texto": "urgente me cobraron dos veces"}, headers=h)
ok("mensaje valido -> 200", r.status_code == 200, r.status_code)
if r.status_code == 200:
    j = r.json()
    for c in ("id", "decision", "probabilidad_alta", "palabras_clave", "motivo", "latencia_ms"):
        ok(f"respuesta incluye '{c}'", c in j)
    ok("decision valida", j.get("decision") in ("ESCALAR", "RESPONDER_NORMAL", "REVISION_MANUAL"), j.get("decision"))
r = S("GET", "/v1/mensajes", headers=h)
ok("historial -> 200 y lista", r.status_code == 200 and isinstance(r.json(), list))
r = S("GET", "/v1/metricas", headers=h)
ok("metricas -> 200 con p50, p95, p99", r.status_code == 200 and all(k in r.json().get("latencia_ms", {}) for k in ("p50", "p95", "p99")))
if a.limite:
    ok(f"tras {a.limite} solicitudes -> 429", 429 in [S("GET", "/v1/mensajes", headers=h).status_code for _ in range(a.limite + 5)])
print(f"\n{sum(res)} de {len(res)} comprobaciones correctas.")
sys.exit(0 if all(res) else 1)
