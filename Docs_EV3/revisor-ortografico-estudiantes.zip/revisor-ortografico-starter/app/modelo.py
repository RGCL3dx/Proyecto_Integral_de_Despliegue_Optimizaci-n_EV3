"""
Modelo de IA del caso EP3: revisor ortografico de texto dentro de imagenes.

TIPO DE MODELO
  Pipeline de dos etapas:
    1) OCR: Tesseract 5 (red neuronal LSTM preentrenada, idioma espanol) lee las palabras de la imagen
       y entrega, para cada una, su posicion y su confianza (0 a 100).
    2) Corrector estadistico basado en frecuencias de uso (idea de Peter Norvig, via pyspellchecker):
         - una palabra poco frecuente o inexistente en el vocabulario es una FALTA;
         - una palabra sin tilde cuya version con tilde es mucho mas frecuente tambien es una FALTA
           ("matricula" se usa mucho menos que "matricula" con tilde);
         - las sugerencias se ordenan por tipo de error, distancia de edicion y frecuencia de uso.

QUE SE "ENTRENA" (AJUSTA)
  El OCR viene preentrenado. Lo que se construye y ajusta con datos (entrenamiento/entrenar.py) es:
    - el VOCABULARIO con frecuencias (derivado de la libreria wordfreq) mas el vocabulario de dominio;
    - los HIPERPARAMETROS:

  umbral_zipf        frecuencia minima (escala Zipf: 1 = rara, 3 = una vez por millon de palabras, 5 = muy comun)
                     para considerar que una palabra existe
  razon_tilde        una palabra sin tilde es falta si su version con tilde es al menos X veces mas frecuente (0 = apagado)
  conf_ocr_min       si el OCR confia menos que esto, la palabra se marca "dudosa" y no "falta"
  largo_minimo       las palabras mas cortas que esto no se revisan
  distancia_max      hasta cuantas ediciones se buscan sugerencias (1 o 2)
  psm                modo de segmentacion de pagina de Tesseract (3 = automatico)

SALIDA INTERPRETABLE
  Cada falta trae: la palabra, la sugerencia, el tipo de error (tilde / letras / desconocida), la distancia de edicion,
  la confianza del OCR, su posicion en la imagen y una explicacion en lenguaje claro.
  La decision de negocio es APROBAR / CORREGIR / REVISION_MANUAL.
"""
from __future__ import annotations

import gzip
import io
import json
import os
import re
import time
import unicodedata
from dataclasses import dataclass
from datetime import date
from pathlib import Path

import pytesseract
from PIL import Image, ImageOps
from pytesseract import Output
from spellchecker import SpellChecker

VERSION_MODELO = "1.0.0"

PARAMS_DEFECTO = {
    "umbral_zipf": 2.0,
    "razon_tilde": 4.0,
    "conf_ocr_min": 60,
    "largo_minimo": 3,
    "distancia_max": 2,
    "psm": 3,
    "idioma_ocr": "spa",
    "max_sugerencias": 3,
}

CARPETA_MODELO_DEFECTO = Path(__file__).resolve().parent.parent / "modelo"
ARCHIVO_VOCABULARIO = "vocabulario.json.gz"

LETRAS = "A-Za-zÁÉÍÓÚÜÑáéíóúüñ"
RE_LETRAS = re.compile(f"[{LETRAS}]+")
CON_TILDE = {"a": "á", "e": "é", "i": "í", "o": "ó", "u": "ú"}
TILDES = set("áéíóúÁÉÍÓÚ")
FRECUENCIA_DOMINIO = 10_000  # los terminos de dominio cuentan como palabras muy usadas (Zipf 4)


# ----------------------------------------------------------------------------- utilidades de texto
def quitar_tildes(texto: str) -> str:
    """Quita tildes y dieresis, pero conserva la n con tilde (n y ñ son letras distintas)."""
    t = texto.replace("ñ", "\x01").replace("Ñ", "\x02")
    t = "".join(c for c in unicodedata.normalize("NFD", t) if unicodedata.category(c) != "Mn")
    return t.replace("\x01", "ñ").replace("\x02", "Ñ")


def distancia_edicion(a: str, b: str) -> int:
    """Distancia de Damerau-Levenshtein: cuantas inserciones, borrados, cambios o intercambios separan a de b."""
    a, b = a.lower(), b.lower()
    d = [[0] * (len(b) + 1) for _ in range(len(a) + 1)]
    for i in range(len(a) + 1):
        d[i][0] = i
    for j in range(len(b) + 1):
        d[0][j] = j
    for i in range(1, len(a) + 1):
        for j in range(1, len(b) + 1):
            costo = 0 if a[i - 1] == b[j - 1] else 1
            d[i][j] = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + costo)
            if i > 1 and j > 1 and a[i - 1] == b[j - 2] and a[i - 2] == b[j - 1]:
                d[i][j] = min(d[i][j], d[i - 2][j - 2] + 1)
    return d[len(a)][len(b)]


def extraer_palabra(token: str) -> str | None:
    """Devuelve la palabra a revisar, o None si el token no es texto revisable (numero, URL, correo, guion...)."""
    if any(c.isdigit() for c in token) or any(c in token for c in "@/\\_#:"):
        return None
    partes = RE_LETRAS.findall(token)
    if len(partes) != 1:
        return None
    return partes[0]


def igualar_mayusculas(original: str, sugerencia: str) -> str:
    if len(original) > 1 and original.isupper():
        return sugerencia.upper()
    if original[:1].isupper():
        return sugerencia[:1].upper() + sugerencia[1:]
    return sugerencia


# ----------------------------------------------------------------------------- etapa 1: OCR
@dataclass
class Palabra:
    texto: str
    conf: float
    x: int
    y: int
    ancho: int
    alto: int
    linea: int


def cargar_imagen(imagen) -> Image.Image:
    """Acepta bytes, una ruta o una imagen PIL."""
    if isinstance(imagen, Image.Image):
        return imagen
    if isinstance(imagen, (bytes, bytearray)):
        img = Image.open(io.BytesIO(imagen))
    else:
        img = Image.open(imagen)
    img.load()
    return img


def leer_palabras(imagen: Image.Image, idioma: str = "spa", psm: int = 3) -> list[Palabra]:
    """Ejecuta el OCR y devuelve las palabras con su caja (en pixeles de la imagen original) y su confianza."""
    img = ImageOps.exif_transpose(imagen)
    if img.mode in ("RGBA", "LA", "P"):
        rgba = img.convert("RGBA")
        fondo = Image.new("RGB", img.size, "white")
        fondo.paste(rgba, mask=rgba.split()[-1])
        img = fondo
    img = img.convert("L")
    factor = 1.0
    if img.width < 1000:  # Tesseract lee mejor letras grandes: ampliamos las imagenes chicas
        factor = 1000 / img.width
        img = img.resize((1000, round(img.height * factor)), Image.LANCZOS)
    d = pytesseract.image_to_data(img, lang=idioma, config=f"--psm {int(psm)}", output_type=Output.DICT)
    lineas: dict[tuple, int] = {}
    palabras: list[Palabra] = []
    for i, texto in enumerate(d["text"]):
        texto = (texto or "").strip()
        try:
            conf = float(d["conf"][i])
        except (TypeError, ValueError):
            continue
        if not texto or conf < 0:
            continue
        clave = (d["block_num"][i], d["par_num"][i], d["line_num"][i])
        n_linea = lineas.setdefault(clave, len(lineas) + 1)
        palabras.append(Palabra(
            texto=texto, conf=conf,
            x=round(d["left"][i] / factor), y=round(d["top"][i] / factor),
            ancho=round(d["width"][i] / factor), alto=round(d["height"][i] / factor),
            linea=n_linea,
        ))
    return palabras


# ----------------------------------------------------------------------------- etapa 2: corrector
class RevisorOrtografico:
    """
    Los hiperparametros umbral_zipf y distancia_max se aplican al construir el objeto (cambian el vocabulario).
    Los demas (razon_tilde, conf_ocr_min, largo_minimo) se leen en cada llamada, por lo que se pueden cambiar
    en self.params sin reconstruir (asi busca entrenar.py los mejores valores rapidamente).
    """

    def __init__(self, vocabulario: dict[str, int], params: dict | None = None,
                 vocabulario_dominio=(), meta: dict | None = None):
        self.params = {**PARAMS_DEFECTO, **(params or {})}
        self.meta = meta or {}
        self.dominio = {w.strip().lower() for w in vocabulario_dominio if w.strip()}
        minimo = 10 ** float(self.params["umbral_zipf"])  # Zipf = log10(apariciones por mil millones de palabras)
        vocab = {w: c for w, c in vocabulario.items() if c >= minimo}
        for w in self.dominio:
            vocab[w] = max(vocab.get(w, 0), FRECUENCIA_DOMINIO)
        self.spell = SpellChecker(language=None, distance=int(self.params["distancia_max"]))
        self.spell.word_frequency.load_json(vocab)
        self._cache_sugerencias: dict[str, list[tuple[str, int]]] = {}

    # ---- persistencia: el "artefacto del modelo" son dos archivos pequenos (modelo.json y vocabulario.json.gz)
    @classmethod
    def cargar(cls, carpeta: str | Path | None = None) -> "RevisorOrtografico":
        """Busca la carpeta del modelo en: el argumento, la variable MODEL_DIR (SageMaker monta el model.tar.gz
        en /opt/ml/model) o la carpeta modelo/ del proyecto."""
        candidatas = [Path(carpeta)] if carpeta else []
        if os.getenv("MODEL_DIR"):
            candidatas.append(Path(os.environ["MODEL_DIR"]))
        candidatas += [Path("/opt/ml/model"), CARPETA_MODELO_DEFECTO]
        for c in candidatas:
            if (c / "modelo.json").is_file() and (c / ARCHIVO_VOCABULARIO).is_file():
                datos = json.loads((c / "modelo.json").read_text(encoding="utf-8"))
                with gzip.open(c / ARCHIVO_VOCABULARIO, "rt", encoding="utf-8") as f:
                    vocabulario = json.load(f)
                return cls(vocabulario, datos.get("params"), datos.get("vocabulario_dominio", []), datos.get("meta"))
        raise FileNotFoundError("No se encontro el modelo (modelo.json + vocabulario.json.gz). "
                                "Ejecuta: python entrenamiento/entrenar.py")

    # ---- consultas al vocabulario
    def frecuencia(self, palabra: str) -> int:
        return self.spell.word_frequency[palabra.lower()]

    def es_conocida(self, palabra: str) -> bool:
        return palabra.lower() in self.spell

    def variante_con_tilde(self, w: str) -> tuple[str, int] | None:
        """La version con tilde mas frecuente de una palabra sin tilde, si existe."""
        if any(c in TILDES for c in w):
            return None
        mejor = None
        for i, c in enumerate(w):
            if c in CON_TILDE:
                v = w[:i] + CON_TILDE[c] + w[i + 1:]
                f = self.frecuencia(v)
                if f > 0 and (mejor is None or f > mejor[1]):
                    mejor = (v, f)
        return mejor

    def sugerir(self, palabra: str) -> list[tuple[str, int]]:
        """Devuelve [(sugerencia, distancia)] ordenadas: primero las que solo difieren en tildes, luego
        la menor distancia de edicion y luego la palabra mas usada."""
        w = palabra.lower()
        if w in self._cache_sugerencias:
            return self._cache_sugerencias[w]
        candidatas = {c for c in (self.spell.candidates(w) or set()) if c != w}
        base = quitar_tildes(w)
        ordenadas = sorted(
            candidatas,
            key=lambda c: (0 if quitar_tildes(c) == base else 1, distancia_edicion(w, c), -self.frecuencia(c)),
        )
        resultado = [(c, distancia_edicion(w, c)) for c in ordenadas[: int(self.params["max_sugerencias"])]]
        self._cache_sugerencias[w] = resultado
        return resultado

    # ---- clasificacion de una palabra ya leida por el OCR
    def evaluar_palabra(self, p: Palabra, con_sugerencias: bool = True) -> dict | None:
        """None = no revisable; si no, {"estado": "ok" | "falta" | "dudosa", ...}."""
        base = extraer_palabra(p.texto)
        if base is None or len(base) < int(self.params["largo_minimo"]):
            return None
        w = base.lower()
        caja = {"x": p.x, "y": p.y, "ancho": p.ancho, "alto": p.alto}

        falta_tilde = None
        if self.es_conocida(w):
            razon = float(self.params["razon_tilde"])
            v = self.variante_con_tilde(w) if razon > 0 else None
            if v is None or v[1] < razon * self.frecuencia(w):
                return {"estado": "ok", "palabra": base}
            falta_tilde = v  # existe, pero la version con tilde se usa mucho mas: casi seguro falta la tilde

        if p.conf < float(self.params["conf_ocr_min"]):
            return {
                "estado": "dudosa", "palabra": base, "confianza_ocr": round(p.conf, 1), "caja": caja, "linea": p.linea,
                "motivo": (f"El OCR no esta seguro de haber leido bien '{base}' (confianza {p.conf:.0f} "
                           f"menor que {self.params['conf_ocr_min']:.0f}). Revisa esa parte de la imagen."),
            }
        if falta_tilde:
            sugerencias = [(falta_tilde[0], 1)]
        else:
            sugerencias = self.sugerir(w) if con_sugerencias else []
        if sugerencias:
            mejor, dist = sugerencias[0]
            tipo = "tilde" if quitar_tildes(mejor) == quitar_tildes(w) else "letras"
            if tipo == "tilde":
                motivo = (f"Falta una tilde (o dieresis): '{base}' deberia escribirse "
                          f"'{igualar_mayusculas(base, mejor)}'.")
            else:
                motivo = (f"'{base}' no existe en el vocabulario. La palabra mas cercana es "
                          f"'{igualar_mayusculas(base, mejor)}' (distancia de edicion {dist}).")
        else:
            mejor, dist, tipo = None, None, "desconocida"
            motivo = (f"'{base}' no existe en el vocabulario y no hay una palabra parecida. "
                      "Si es un nombre propio o una sigla, agregala al vocabulario de dominio.")
        return {
            "estado": "falta", "palabra": base, "tipo": tipo, "distancia": dist,
            "sugerencias": [igualar_mayusculas(base, s) for s, _ in sugerencias],
            "confianza_ocr": round(p.conf, 1), "caja": caja, "linea": p.linea, "motivo": motivo,
        }

    @staticmethod
    def decidir(n_faltas: int, n_dudosas: int, n_revisadas: int) -> tuple[str, str]:
        """Regla de negocio que usa el area de comunicaciones (ver el enunciado del caso)."""
        if n_revisadas == 0:
            return "REVISION_MANUAL", "No se detecto texto revisable: una persona debe mirar la imagen."
        if n_faltas > 0:
            return "CORREGIR", f"Se encontraron {n_faltas} posible(s) falta(s) de ortografia. No publicar hasta corregirlas."
        if n_dudosas > 0:
            return "REVISION_MANUAL", f"No hay faltas claras, pero {n_dudosas} palabra(s) no se leyeron con seguridad."
        return "APROBAR", "No se encontraron faltas de ortografia."

    def revisar_palabras(self, palabras: list[Palabra], con_sugerencias: bool = True) -> dict:
        faltas, dudosas, revisadas = [], [], 0
        for p in palabras:
            r = self.evaluar_palabra(p, con_sugerencias)
            if r is None:
                continue
            revisadas += 1
            if r["estado"] == "falta":
                faltas.append({k: v for k, v in r.items() if k != "estado"})
            elif r["estado"] == "dudosa":
                dudosas.append({k: v for k, v in r.items() if k != "estado"})
        decision, motivo = self.decidir(len(faltas), len(dudosas), revisadas)
        return {
            "modelo_version": self.meta.get("version", VERSION_MODELO),
            "decision": decision,
            "motivo_decision": motivo,
            "resumen": {"palabras_leidas": len(palabras), "palabras_revisadas": revisadas,
                        "faltas": len(faltas), "dudosas": len(dudosas)},
            "faltas": faltas,
            "dudosas": dudosas,
            "texto_detectado": " ".join(p.texto for p in palabras),
        }

    def revisar(self, imagen) -> dict:
        t0 = time.perf_counter()
        img = cargar_imagen(imagen)
        palabras = leer_palabras(img, self.params["idioma_ocr"], self.params["psm"])
        resultado = self.revisar_palabras(palabras)
        resultado["imagen"] = {"ancho": img.width, "alto": img.height}
        resultado["tiempo_ms"] = round((time.perf_counter() - t0) * 1000, 1)
        return resultado


def guardar_modelo(carpeta: str | Path, vocabulario: dict[str, int], params: dict, vocabulario_dominio,
                   metricas: dict | None = None, extra_meta: dict | None = None) -> None:
    """Escribe el artefacto del modelo: modelo.json + vocabulario.json.gz."""
    carpeta = Path(carpeta)
    carpeta.mkdir(parents=True, exist_ok=True)
    meta = {"version": VERSION_MODELO, "creado": date.today().isoformat(), **(extra_meta or {})}
    if metricas:
        meta["metricas"] = metricas
    datos = {"params": params, "vocabulario_dominio": sorted(set(vocabulario_dominio)), "meta": meta}
    (carpeta / "modelo.json").write_text(json.dumps(datos, ensure_ascii=False, indent=2), encoding="utf-8")
    with gzip.open(carpeta / ARCHIVO_VOCABULARIO, "wt", encoding="utf-8", compresslevel=9) as f:
        json.dump(vocabulario, f, ensure_ascii=False, separators=(",", ":"))
