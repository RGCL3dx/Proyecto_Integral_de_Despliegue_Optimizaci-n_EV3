"""
Mide la calidad del modelo con la particion TEST (imagenes que no se usaron para elegir los hiperparametros).

  python entrenamiento/evaluar.py --datos datos --modelo modelo --salida resultados/evaluacion.json

Entrega accuracy, precision, recall y F1 a nivel de imagen, y precision, recall y F1 a nivel de palabra,
en total y por dificultad (facil / media / dificil), mas la exactitud de la primera sugerencia.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from comun import calcular_metricas, cargar_etiquetas, ocr_de_todas  # noqa: E402

from app.modelo import RevisorOrtografico  # noqa: E402

RAIZ = Path(__file__).resolve().parent.parent


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--datos", default=str(RAIZ / "datos"))
    ap.add_argument("--modelo", default=str(RAIZ / "modelo"))
    ap.add_argument("--particion", default="test", choices=["train", "test"])
    ap.add_argument("--salida", default=str(RAIZ / "resultados" / "evaluacion.json"))
    a = ap.parse_args()

    revisor = RevisorOrtografico.cargar(a.modelo)
    filas = cargar_etiquetas(a.datos, a.particion)
    print(f"Evaluando {len(filas)} imagenes de '{a.particion}' con el modelo {revisor.meta.get('version')}...")
    ocr = ocr_de_todas(filas, a.datos, psm=revisor.params["psm"], idioma=revisor.params["idioma_ocr"])
    m = calcular_metricas(revisor, filas, ocr, con_sugerencias=True)

    print(f"\n{'grupo':8} {'imgs':>5} | IMAGEN  acc   prec  recall   F1  | PALABRA  prec  recall   F1   sug.top1  (TP FP FN)")
    for g, v in m.items():
        i, p = v["imagen"], v["palabra"]
        print(f"{g:8} {i['imagenes']:>5} |        {i['accuracy']:.3f} {i['precision']:.3f} {i['recall']:.3f}  {i['f1']:.3f} |"
              f"        {p['precision']:.3f} {p['recall']:.3f}  {p['f1']:.3f}   {p['sugerencia_top1']:.3f}    ({p['tp']} {p['fp']} {p['fn']})")
    print("\nMatriz de confusion por imagen (todas):", m["todas"]["imagen"]["matriz"])
    Path(a.salida).parent.mkdir(parents=True, exist_ok=True)
    Path(a.salida).write_text(json.dumps({"particion": a.particion, "params": revisor.params, "metricas": m},
                                         ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Guardado en {a.salida}")


if __name__ == "__main__":
    main()
